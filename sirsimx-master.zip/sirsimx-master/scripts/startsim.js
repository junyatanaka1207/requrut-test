// variable that holds the simulation
var sirsim;

//variable holding the graph
var graph;

$(() => {
  sirsim = new p5(sketch);
  graph = new p5(graphSketch);
});